<?php 
include('connection.php'); 
include('tags.php'); 
?>

<!DOCTYPE html>
<html>
<head>
  <title>Maroon Board</title>
  <style>
    *{
      margin: 0;
      padding: 0;
    }
    .navbar-default .navbar-nav > li > a {
      color: #800000 !important;
    }

    .navbar-default .navbar-nav > li > a:hover {
      color: #460000 !important;
    }

    .default_red:hover {
      border: 1px solid #800000; border-radius: 20px;
    }
    [hidden] {
  display: none !important;
}
/*
    .navbar-default {
      border-color: #800000 !important;
    }*/

  </style>
</head>
<body>

<?php 
include('admin_navbar.php');

?>



  
<?php 
$username = $_SESSION['username'];
$query = mysqli_query($conn, "SELECT * FROM tbl_categories ORDER BY id DESC");

?>




<?php 
if(isset($_POST["add_admin"]))
{
  echo "<meta http-equiv='refresh' content='0'>";
$last_name = $_POST['last_name'];
$first_name = $_POST['first_name'];
$middle_name = $_POST['middle_name'];
$username = $_POST['username']; 
$password = $_POST['password'];

$query_insert = mysqli_query($conn, "INSERT INTO tbl_admin_credentials VALUES('', '$last_name', '$first_name', '$middle_name', '$username', '$password')");  
if($query_insert){

  echo '<div class="alert alert-success">
  <strong>Success!</strong> New Admin Added!
</div>';
}



}
?>

<br><br>
<div class="container">
<button class="btn btn-primary" data-toggle="modal" data-target="#modalAddNew">Add New Product</button>
<br><br>
<table class='table table-bordered table-striped'>
  <tr style="background: #d9d9d9 !important; text-align: center;">
      <th>ID</th>
      <th>Category Name</th>
      <th>Product Name</th>
      <th>Product Image</th>   
      <th>Product Price</th>                             
  </tr>

  <?php while($row = mysqli_fetch_array($query)){ ?>
  <tr>
      <td><?php echo $row["id"]; ?> </td>
      <td><?php echo $row["category_name"]; ?> </td>
      <td><?php echo $row["product_name"]; ?> </td>
      <td><img src="shopping_cart/<?php echo $row["product_image"]; ?>" width="160" height="160"></td>
      <td><?php echo $row["product_price"]; ?> </td>
  </tr>
  <?php
  
}

  ?>

</table>
</div>



<div class="modal" id="modalAddNew" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add New Product</h4>
        </div>
        <div class="modal-body">
          <form action="" method="post">
            <div class="form-group">
              <label for="email">Category Name:</label>
              <select name="enr" class="form-control" placeholder="Enter Category Name" required>                                                 
                <?php 
                    $res = mysqli_query($conn, "SELECT category_name from tbl_categories");
                    echo '<option disabled selected>Choose Your Category Name</option>';  
                      while($row = mysqli_fetch_array($res)) { 

                      echo '<option> ';
                          echo $row["category_name"]; 
                      echo '</option> ';
                      }
                ?>
             </select>
            </div>
            <div class="form-group">
              <label for="pwd">Product Name:</label>
              <input type="text" class="form-control"  placeholder="Enter product name" name="product_name">
            </div>
            <div class="form-group">
              <label for="pwd">Product Image:</label>
              <label class="btn btn-default btn-block">
                   Browse <input type="file" hidden class="form-control">
              </label>
              
            </div>
            <div class="form-group">
              <label for="pwd">Product Price:</label>
              <input type="text" class="form-control"  placeholder="Enter price" name="username">
            </div>

<!--             <input type="hidden" value="<?php echo $_SESSION['username']; ?>" name="username"> -->

          <!--   <div class="checkbox">
              <label><input type="checkbox" name="remember"> Remember me</label>
            </div> -->          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <input type="submit" class="btn btn-primary" name="add_admin" value="Add New Product">
          </form>
        </div>
      </div>
      
    </div>
  </div>


</body>
</html>