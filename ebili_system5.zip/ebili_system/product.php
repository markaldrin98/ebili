<?php 
include('connection.php'); 
include('tags.php'); 
?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
  <style>
    *{
      margin: 0;
      padding: 0;
    }
    .navbar-default .navbar-nav > li > a {
      color: #449d44 !important;
    }

    .navbar-default .navbar-nav > li > a:hover {
      color: #2a772a !important;
    }

    .modal {
     text-align: center;
    }

    .product-item {
  float: left;
  background: #ffffff;
  margin: 30px 30px 0px 0px;
  border: #E0E0E0 1px solid;
}

.product-image {
  height: 155px;
  width: 250px;
  background-color: #FFF;
}

.product-tile-footer {
    padding: 15px 15px 0px 15px;
    overflow: auto;
}

.product-title {
  margin-bottom: 20px;
}

.product-price {
  float:left;
}

.cart-action {
  float: right;
}

.zoom-hover {
  border:2px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px; margin: 15px;
}

.zoom-hover:hover {
 border: solid 2px #449d44;
 cursor: pointer;
}



    @media screen and (min-width: 768px) { 
      .modal:before {
        display: inline-block;
        vertical-align: middle;
        content: " ";
        height: 100%;
      }
    }

    .modal-dialog {
      display: inline-block;
      text-align: left;
      vertical-align: middle;
    }
/*
    .navbar-default {
      border-color: #800000 !important;
    }*/

  </style>
</head>
<body>

<?php
include('customer_navbar.php');
?>


<div class="modal" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Choose your user type</h4>
        </div>
        <div class="modal-body">
          <a href="customer_login.php"><button type="button" class="btn btn-primary btn-block" style="margin-bottom: 1rem;">Log in as Customer</button></a>
          <a href="admin_login.php"><button type="button" class="btn btn-primary btn-block">Log in as Admin</button></a>
        </div>
        
      </div>
      
    </div>
  </div>

<div class="jumbotron text-center mt-4">
  
  <h1>Welcome to E-Bili System!</h1>
  <p>E-Bili Opening. Coming Soon!</p>
</div>
  
<div class="container">
  <div class="row">
    <a href="customer_dashboard.php"><button class="btn btn-primary">Back</button></a>
    <h3 align="center">E Bili Products</h3>
    <br>
   

    <?php 

    if(isset($_POST["add_to_cart"]))
{

  if(isset($_SESSION["shopping_cart"]))
  {
    $item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
    if(!in_array($_GET["id"], $item_array_id))
    {
      $count = count($_SESSION["shopping_cart"]);
      $item_array = array(
        'item_id'     =>  $_GET["id"],
        'item_name'     =>  $_POST["hidden_name"],
        'item_price'    =>  $_POST["hidden_price"],
        'item_quantity'   =>  $_POST["quantity"]
      );
      $_SESSION["shopping_cart"][$count] = $item_array;
    }
    else
    {
      echo '<script>alert("Item Already Added")</script>';
    }
  }
  else
  {
    $item_array = array(
      'item_id'     =>  $_GET["id"],
      'item_name'     =>  $_POST["hidden_name"],
      'item_price'    =>  $_POST["hidden_price"],
      'item_quantity'   =>  $_POST["quantity"]
    );
    $_SESSION["shopping_cart"][0] = $item_array;
  }
}

if(isset($_GET["action"]))
{

  if($_GET["action"] == "delete")
  {

    foreach($_SESSION["shopping_cart"] as $keys => $values)
    {
      if($values["item_id"] == $_GET["id"])
      {

        unset($_SESSION["shopping_cart"][$keys]);
        echo '<script>alert("Item Removed")</script>';
        echo '<script>window.location="product.php?action=add&id=<?php echo $row["id"]; ?>"</script>';
      }
    }
  }
}


// this part still needs to be fixed

// $res2 = "SELECT tbl_product.* FROM tbl_product, tbl_categories WHERE tbl_categories.id = tbl_product.id AND id='$id'";


$id = $_GET["id"];
$query = "SELECT * FROM tbl_product WHERE id='$id'";


        $result = mysqli_query($conn, $query);
        if(mysqli_num_rows($result) > 0)
        {
          while($row = mysqli_fetch_array($result))
          {
        ?>
      <div class="col-md-4">
        <form method="post" action="product.php?action=add&id=<?php echo $row["id"]; ?>">

            <a href="product.php?action=add&id=<?php echo $row["id"]; ?>">
              <div align="center" class="zoom-hover">
            </a>


             <img src="shopping_cart/<?php echo $row["product_image"]; ?>" class="img-responsive " style="width: 150px; height: 150px;"/><br />


            <!-- <h4 class="text-info"><?php echo $row["category_name"]; ?></h4> -->
    
            <h4 class="text-info"><?php echo $row["product_name"]; ?></h4>
            <h4 class="text-danger">Price: P<?php echo $row["product_price"]; ?></h4>

            <input type="text" name="quantity" placeholder="Quantity" class="form-control" />

            <input type="hidden" name="hidden_name" value="<?php echo $row["category_name"]; ?>" />

            <input type="hidden" name="hidden_price" value="<?php echo $row["product_price"]; ?>" />


            
            <input type="submit" name="add_to_cart" style="margin-top:5px;" 


            <?php if(!isset($_SESSION['username'])) { 
                echo 'class="btn btn-disabled" disabled';
              }
              else{
                  echo 'class="btn btn-success"';
              }
            ?> 
            class="" value="Add to Cart" />

          </div>

        </form>
      </div>
      <?php
          }
        }
      ?>
      <div style="clear:both"></div>
      <br />
      <h3>Order Details</h3>
      <div class="table-responsive">
        <table class="table table-bordered">
          <tr>
            <th width="40%">Item Name</th>
            <th width="10%">Quantity</th>
            <th width="20%">Price</th>
            <th width="15%">Total</th>
            <th width="5%">Action</th>
          </tr>
          <?php
          if(!empty($_SESSION["shopping_cart"]))
          {

            $total = 0;
            foreach($_SESSION["shopping_cart"] as $keys => $values)
            {
              
          ?>
          <tr>
            <td><?php echo $values["item_name"]; ?></td>
            <td><?php echo $values["item_quantity"]; ?></td>
            <td>$ <?php echo $values["item_price"]; ?></td>
            <td>$ <?php echo number_format($values["item_quantity"] * $values["item_price"], 2);?></td>
            <td><a href="product.php?action=delete&id=<?php echo $values["item_id"]; ?>"><span class="text-danger">Remove</span></a></td>
          </tr>
          <?php
              $total = $total + ($values["item_quantity"] * $values["item_price"]);
            }
          ?>
          <tr>
            <td colspan="3" align="right"><b>Total</b></td>
            <td align=""><b>$ <?php echo number_format($total, 2); ?></b></td>
            <td></td>
          </tr>
          <?php
          }
          ?>
            
        </table>
      </div>
    </div>
  </div>
  <br />
  </body>
</html>
