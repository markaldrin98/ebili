<?php 
include('connection.php'); 
include('tags.php'); 
?>

<!DOCTYPE html>
<html>
<head>
  <title>E-Bili System</title>
  <style>
    *{
      margin: 0;
      padding: 0;
    }
    .navbar-default .navbar-nav > li > a {
      color: #800000 !important;
    }

    .navbar-default .navbar-nav > li > a:hover {
      color: #460000 !important;
    }

    .default_red:hover {
      border: 1px solid #800000; border-radius: 20px;
    }
/*
    .navbar-default {
      border-color: #800000 !important;
    }*/

    .panel-default:hover{
      border: solid 1px #800000;
    }
    .panel-heading:hover{
      background: #800000;
      color: white;
      cursor: pointer;
    }

     .modal {
     text-align: center;
    }

    @media screen and (min-width: 768px) { 
      .modal:before {
        display: inline-block;
        vertical-align: middle;
        content: " ";
        height: 100%;
      }
    }

    .modal-dialog {
      display: inline-block;
      text-align: left;
      vertical-align: middle;
    }

  </style>
</head>
<body>

<?php 
include('admin_navbar.php');

?>


<div class="jumbotron mt-4">
  
<?php 
$username = $_SESSION['username'];
$_SESSION['username'] = $username;
$query = mysqli_query($conn, "SELECT * FROM tbl_classroom");

?>

<div class="text-center">
  <h1>Welcome to E-Bili System!</h1>
  <p>E-Bili Opening. Coming Soon!</p>
</div>

<div class="container">










</div>
</div>

<!--  
<div class="container">
  <div class="row">
    <div class="col-sm-4" class="default_red">
         <div class="panel panel-primary">
            <div class="panel-heading">Panel with panel-primary class</div>
            <div class="panel-body">Panel Content</div>
        </div>
    </div>
    <div class="col-sm-4" class="default_red">
        <div class="panel panel-primary">
            <div class="panel-heading">Panel with panel-primary class</div>
            <div class="panel-body">Panel Content</div>
        </div>
    </div>
    <div class="col-sm-4" class="default_red">
        <div class="panel panel-primary">
           <div class="panel-heading">Panel with panel-primary class</div>
           <div class="panel-body">Panel Content</div>
        </div>
    </div>
  </div>
</div>
-->

</body>
</html>