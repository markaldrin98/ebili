<?php 
   $conn = mysqli_connect("localhost", "root", "", "ebili_db");
                 
?>