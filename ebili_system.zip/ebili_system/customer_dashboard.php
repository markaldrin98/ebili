<?php 
include('connection.php'); 
include('tags.php'); 
?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
  <style>
    *{
      margin: 0;
      padding: 0;
    }
    .navbar-default .navbar-nav > li > a {
      color: #800000 !important;
    }

    .navbar-default .navbar-nav > li > a:hover {
      color: #460000 !important;
    }

    .default_red:hover {
      border: 1px solid #800000; border-radius: 20px;
    }

    .panel-default:hover{
      border: solid 1px #800000;
    }
    .panel-heading:hover{
      background: #800000;
      color: white;
      cursor: pointer;
    }

      .modal {
     text-align: center;
    }

    @media screen and (min-width: 768px) { 
      .modal:before {
        display: inline-block;
        vertical-align: middle;
        content: " ";
        height: 100%;
      }
    }

    .modal-dialog {
      display: inline-block;
      text-align: left;
      vertical-align: middle;
    }
/*
    .navbar-default {
      border-color: #800000 !important;
    }*/

  </style>
</head>
<body>

<?php 
include('customer_navbar.php');

?>

<?php 
if(isset($_POST["join_room"]))
{
$count = 0;    
$class_code = $_POST['class_code'];
  




$count = mysqli_num_rows($res);    

    if($count == 0) { 
    echo '<div class="alert alert-danger alertClass">
    <center>
    <!--  <button type="button" class="close" data- ="alert">&times;</button> -->

    <strong>Invalid</strong> Class Code!
    </center>
    </div> ';
    }
    else { 
        echo '<div class="alert alert-success alertClass">
              <center>
              Joined Success!<strong></strong> 
              </center>
              </div> ';


        $row = mysqli_fetch_assoc($res);

        


        

        $query_insert = mysqli_query($conn, "INSERT INTO tbl_classroom_status VALUES('', '$class_code', '".$_SESSION['username']."', 'Joined')");   
            


        }

    
}
?>

<div class="container">

<div class="jumbotron text-center">
  <h1>Welcome to E-Bili System!</h1>
  <p>E-Bili Opening. Coming Soon!</p>
</div>

<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <h3>Column 1</h3>
      <p>Lorem ipsum dolor..</p>
    </div>
    <div class="col-sm-4">
      <h3>Column 2</h3>
      <p>Lorem ipsum dolor..</p>
    </div>
    <div class="col-sm-4">
      <h3>Column 3</h3>
      <p>Lorem ipsum dolor..</p>
    </div>
  </div>
</div>




</body>
</html>