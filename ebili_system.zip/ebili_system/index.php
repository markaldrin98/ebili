<?php 
include('connection.php'); 
include('tags.php'); 
?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
  <style>
    *{
      margin: 0;
      padding: 0;
    }
    .navbar-default .navbar-nav > li > a {
      color: #800000 !important;
    }

    .navbar-default .navbar-nav > li > a:hover {
      color: #460000 !important;
    }

    .modal {
     text-align: center;
    }

    @media screen and (min-width: 768px) { 
      .modal:before {
        display: inline-block;
        vertical-align: middle;
        content: " ";
        height: 100%;
      }
    }

    .modal-dialog {
      display: inline-block;
      text-align: left;
      vertical-align: middle;
    }
/*
    .navbar-default {
      border-color: #800000 !important;
    }*/

  </style>
</head>
<body>

<nav class="navbar navbar-default" style="padding: 10px;">
  <div class="container-fluid">
    <div class="navbar-header" style="background: ">
  
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>

      <a style="font-weight: bold; color: #800000; margin-left: 0.5px;" class="navbar-brand" href="#"><span class="glyphicon glyphicon-shopping-cart"></span> E-Bili System</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class=""><a href="#">Home</a></li>
        <!-- <li><a href="#">Page 1</a></li>
        <li><a href="#">Page 2</a></li> 
 -->      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="customer_registration.php"><span class="glyphicon glyphicon-user"></span> Register</a></li>
        <li data-toggle="modal" data-target="#myModal"><a href="#"><span class="glyphicon glyphicon-log-in" class="btn btn-info btn-lg"></span> Login</a></li>
      </ul>
    </div>
  </div>
</nav>


<div class="modal" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Choose your user type</h4>
        </div>
        <div class="modal-body">
          <a href="customer_login.php"><button type="button" class="btn btn-primary btn-block" style="margin-bottom: 1rem;">Log in as Customer</button></a>
          <a href="admin_login.php"><button type="button" class="btn btn-primary btn-block">Log in as Admin</button></a>
        </div>
        
      </div>
      
    </div>
  </div>

<div class="jumbotron text-center mt-4">
  
  <h1>Welcome to E-Bili System!</h1>
  <p>E-Bili Opening. Coming Soon!</p>
</div>
  
<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <h3>Column 1</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
      <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
    </div>
    <div class="col-sm-4">
      <h3>Column 2</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
      <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
    </div>
    <div class="col-sm-4">
      <h3>Column 3</h3>        
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit...</p>
      <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris...</p>
    </div>
  </div>
</div>
</body>
</html>