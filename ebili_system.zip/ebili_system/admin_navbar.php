<?php
session_start();
?>

<nav class="navbar navbar-default" style="padding: 10px;">
  <div class="container-fluid">
    <div class="navbar-header" style="background: ">
     
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>

      <a style="font-weight: bold; color: #800000; margin-left: 0.5px;" class="navbar-brand" href="teacher_dashboard.php"><span class="glyphicon glyphicon-shopping-cart"></span> E-Bili System</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class=""><a href="#">Welcome, <?php echo $_SESSION['username']; ?></a></li>
        <!-- <li><a href="#">Page 1</a></li>
        <li><a href="#">Page 2</a></li> 
 -->      </ul>
      <ul class="nav navbar-nav navbar-right">     

       
        <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> Manage All
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="admin_manage_admins.php">Manage Admin</a></li>
          <li><a href="admin_manage_customers.php">Manage Customers</a></li>
        </ul>
      </li>
        <li>
          <a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<?php 
if(isset($_POST["register"]))
{
$class_code = $_POST['class_code'];
$section = $_POST['section'];
$subject = $_POST['subject'];
$room = $_POST['room'];
$username = $_POST['username']; 
$class_date = $_POST['class_date'];
$class_time = $_POST['class_time'];

$query_insert = mysqli_query($conn, "INSERT INTO tbl_classroom VALUES('', '$class_code', '$section', '$subject', '$room', '$username', '$class_date', '$class_time')");  

if($query_insert){
  $query_insert_status = mysqli_query($conn, "INSERT INTO tbl_classroom_status VALUES('', '$class_code', '$username', 'Joined')");  

  echo '<div class="alert alert-success alertClass">
  <center>
  <!--  <button type="button" class="close" data- ="alert">&times;</button> -->

    Class <strong>Created!</strong>
  </center>
  </div> ';
}

}



?>


<div class="modal" id="modalClass" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Create Class</h4>
        </div>
        <div class="modal-body">
          <form action="" method="post">
            <div class="form-group">
              <label for="email">Class Code:</label>
              <input type="text" class="form-control text-uppercase" id="email" placeholder="Enter class code. Maximum of 7" name="class_code" maxlength="7">
            </div>
            <div class="form-group">
              <label for="pwd">Section:</label>
              <input type="text" class="form-control" id="pwd" placeholder="Enter section" name="section">
            </div>
            <div class="form-group">
              <label for="pwd">Subject:</label>
              <input type="text" class="form-control" id="pwd" placeholder="Enter subject" name="subject">
            </div>
            <div class="form-group">
              <label for="pwd">Room:</label>
              <input type="text" class="form-control" id="pwd" placeholder="Enter room" name="room">
            </div>
            <div class="form-group">
              <label for="pwd">Date:</label>
              <input type="text" readonly class="form-control" id="pwd" placeholder="Enter room" name="class_date" value="<?php echo date("F j Y "); ?>" name="class_date">
            </div>
            <div class="form-group">
              <label for="pwd">Time:</label>
              <input type="text" readonly class="form-control" id="pwd" name="class_time" value="<?php echo date("h:i:sa"); ?>" name="class_time">
            </div>




            <input type="hidden" value="<?php echo $_SESSION['username']; ?>" name="username">

          <!--   <div class="checkbox">
              <label><input type="checkbox" name="remember"> Remember me</label>
            </div> -->
            
          
        </div>
        <div class="modal-footer">

          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <input type="submit" class="btn btn-primary" name="register" value="Create Class">
          </form>
        </div>
      </div>
      
    </div>
  </div>