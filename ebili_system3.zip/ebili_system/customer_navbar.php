<?php
session_start();
?>

<nav class="navbar navbar-default" style="padding: 10px;">
  <div class="container-fluid">
    <div class="navbar-header" style="background: ">
     
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>

      <a style="font-weight: bold; color: #449d44; margin-left: 0.5px;" class="navbar-brand" href="customer_dashboard.php"><span class="glyphicon glyphicon-shopping-cart"></span> E-Bili System</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class=""><a href="customer_dashboard.php">Home</a></li>
        <li class=""><a href="#">Welcome, <?php echo $_SESSION['username']; ?></a></li>
        <!-- <li><a href="#">Page 1</a></li>
        <li><a href="#">Page 2</a></li> 
 -->      </ul>
      <ul class="nav navbar-nav navbar-right">
        <!-- <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Class
        <span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="#">Join Class</a></li>
          <li><a href="#">Page 1-2</a></li>
          <li><a href="#">Page 1-3</a></li>
        </ul>
      </li> -->

        <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>