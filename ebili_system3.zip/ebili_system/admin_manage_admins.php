<?php 
include('connection.php'); 
include('tags.php'); 
?>

<!DOCTYPE html>
<html>
<head>
  <title>Maroon Board</title>
  <style>
    *{
      margin: 0;
      padding: 0;
    }
    .navbar-default .navbar-nav > li > a {
      color: #800000 !important;
    }

    .navbar-default .navbar-nav > li > a:hover {
      color: #460000 !important;
    }

    .default_red:hover {
      border: 1px solid #800000; border-radius: 20px;
    }
/*
    .navbar-default {
      border-color: #800000 !important;
    }*/

  </style>
</head>
<body>

<?php 
include('admin_navbar.php');

?>



  
<?php 
$username = $_SESSION['username'];
$query = mysqli_query($conn, "SELECT * FROM tbl_admin_credentials ORDER BY id DESC");

?>




<?php 
if(isset($_POST["add_admin"]))
{
  echo "<meta http-equiv='refresh' content='0'>";
$last_name = $_POST['last_name'];
$first_name = $_POST['first_name'];
$middle_name = $_POST['middle_name'];
$username = $_POST['username']; 
$password = $_POST['password'];

$query_insert = mysqli_query($conn, "INSERT INTO tbl_admin_credentials VALUES('', '$last_name', '$first_name', '$middle_name', '$username', '$password')");  
if($query_insert){

  echo '<div class="alert alert-success">
  <strong>Success!</strong> New Admin Added!
</div>';
}



}
?>

<br><br>
<div class="container">
<button class="btn btn-primary" data-toggle="modal" data-target="#modalAddNew">Add New Admin</button>
<br><br>
<table class='table table-bordered table-striped'>
  <tr style="background: #d9d9d9 !important; text-align: center;">
      <th>ID</th>
      <th>Last Name</th>
      <th>First Name</th>
      <th>Middle Name</th>
      <th>Username</th>   
      <th>Password</th>                             
  </tr>

  <?php while($row = mysqli_fetch_array($query)){ ?>
  <tr>
      <td><?php echo $row["id"]; ?> </td>
      <td><?php echo $row["last_name"]; ?> </td>
      <td><?php echo $row["first_name"]; ?> </td>
      <td><?php echo $row["middle_name"]; ?> </td>
      <td><?php echo $row["username"]; ?> </td>
      <td><?php echo $row["password"]; ?> </td>
  </tr>
  <?php
  
}

  ?>

</table>
</div>



<div class="modal" id="modalAddNew" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add New Admin</h4>
        </div>
        <div class="modal-body">
          <form action="" method="post">
            <div class="form-group">
              <label for="email">Last Name:</label>
              <input type="text" class="form-control" placeholder="Enter last name" name="last_name">
            </div>
            <div class="form-group">
              <label for="pwd">First Name:</label>
              <input type="text" class="form-control"  placeholder="Enter first name" name="first_name">
            </div>
            <div class="form-group">
              <label for="pwd">Middle Name:</label>
              <input type="text" class="form-control"  placeholder="Enter middle name" name="middle_name">
            </div>
            <div class="form-group">
              <label for="pwd">Username:</label>
              <input type="text" class="form-control"  placeholder="Enter username" name="username">
            </div>
            <div class="form-group">
              <label for="pwd">Password:</label>
              <input type="password" class="form-control"  placeholder="Enter password" name="password">
            </div>

<!--             <input type="hidden" value="<?php echo $_SESSION['username']; ?>" name="username"> -->

          <!--   <div class="checkbox">
              <label><input type="checkbox" name="remember"> Remember me</label>
            </div> -->          
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <input type="submit" class="btn btn-primary" name="add_admin" value="Add New Admin">
          </form>
        </div>
      </div>
      
    </div>
  </div>


</body>
</html>