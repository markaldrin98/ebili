<?php 
include "connection.php";

$id = $_GET["id"];
$res = mysqli_query($conn, "SELECT * FROM tbl_product WHERE id='$id'");
$row = mysqli_fetch_assoc($res);

$product_name = $row;


$res2 = mysqli_query($conn, "SELECT tbl_product.* FROM tbl_product, tbl_categories WHERE tbl_categories.category_name = tbl_product.category_name AND product_name = " .$product_name["product_name"]);
while($row = mysqli_fetch_array($res2)) {
?>
<table>
    <tr>
    <td><?php echo $row["product_name"]; ?> </td>
</tr>
</table>
<?php
}

?>

<script>
	// window.location = "return_book.php";
</script>