-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 25, 2021 at 10:23 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ebili_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_credentials`
--

CREATE TABLE `tbl_admin_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_admin_credentials`
--

INSERT INTO `tbl_admin_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`) VALUES
(1, 'Cruz', 'Maria', '', 'admin', 'admin'),
(2, 'Test', 'Test', 'Test', 'davi04', 'davi04');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_announcement`
--

CREATE TABLE `tbl_announcement` (
  `id` int(15) NOT NULL,
  `username` varchar(15) NOT NULL,
  `announcement` longtext NOT NULL,
  `post_date` varchar(20) NOT NULL,
  `post_time` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_categories`
--

CREATE TABLE `tbl_categories` (
  `id` int(25) NOT NULL,
  `category_name` varchar(200) NOT NULL,
  `image` varchar(200) NOT NULL,
  `price` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_categories`
--

INSERT INTO `tbl_categories` (`id`, `category_name`, `image`, `price`) VALUES
(1, 'Babies Needs', 'BabiesNeeds.jpg', '25.00'),
(2, 'Beverages', 'Beverages.jpg', '15.00'),
(3, 'Breads', 'Breads.jpg', '10.00'),
(4, 'Canned Goods', 'CannedGoods.jpg', '20.00'),
(5, 'Cooking', 'Cooking.jpg', '30.00'),
(6, 'DairyAndEggs', 'DairyAndEggs.jpg', '22.00'),
(7, 'FreshCounter', 'FreshCounter.jpg', '10.00'),
(8, 'Fresh Produce', 'FreshProduce.jpg', '12.00'),
(9, 'Household', 'Household.jpg', '15.00'),
(10, 'Instant Noodles', 'InstantNoodles.jpg', '10.00'),
(11, 'Personal Care', 'PersonalCare.jpg', '40.00'),
(12, 'Pets', 'Pets.jpg', '15.00'),
(13, 'Rice', 'Rice.jpg', '10.00'),
(14, 'Vitamins And Supplements', 'VitaminsAndSupplements.jpg', '30.00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer_credentials`
--

CREATE TABLE `tbl_customer_credentials` (
  `id` int(11) NOT NULL,
  `last_name` varchar(200) NOT NULL,
  `first_name` varchar(200) NOT NULL,
  `middle_name` varchar(200) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `email` varchar(200) NOT NULL,
  `address` varchar(250) NOT NULL,
  `contact_number` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_customer_credentials`
--

INSERT INTO `tbl_customer_credentials` (`id`, `last_name`, `first_name`, `middle_name`, `username`, `password`, `email`, `address`, `contact_number`) VALUES
(1, 'Abcede', 'John Lloyd', 'Cruz', 'johncruz', 'johncruz', 'johnlloyd@gmail.com', 'test', '09616124507'),
(2, 'Salva', 'Kyla', 'Krystelle', 'kyla04', 'kyla04', 'kylasalva@gmail.com', 'test', '09517610952'),
(3, 'Daludado', 'Davienne Rose', 'Antipolo', 'davissi', '090401', 'rosedaludado0904@gmail.com', 'test', '+63212716501'),
(4, 'Daludado', 'Davienne Rose', 'Antipolo', 'davi', '090401', 'rosedaludado0904@gmail.com', 'Vicar Village, NBP Reservation, Poblacion, Muntinlupa City', '+63212716501'),
(5, 'Cruz', 'Juan', 'Dela', 'juancruz04', 'juancruz04', 'juancruz@gmail.com', '4421 Aglipay st. Quezon City', '09123456789'),
(6, 'TEST', 'TEST', 'TEST', 'juancruz04', 'TEST', 'TEST@GMAIL.COM', 'TEST', 'TEST');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(25) NOT NULL,
  `category_name` varchar(200) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `product_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `category_name`, `product_name`, `product_image`) VALUES
(1, 'Babies Needs', 'Feeding Bottle', 'BabiesNeeds.jpg\r\n');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_announcement`
--
ALTER TABLE `tbl_announcement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_categories`
--
ALTER TABLE `tbl_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_customer_credentials`
--
ALTER TABLE `tbl_customer_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin_credentials`
--
ALTER TABLE `tbl_admin_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_announcement`
--
ALTER TABLE `tbl_announcement`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_categories`
--
ALTER TABLE `tbl_categories`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_customer_credentials`
--
ALTER TABLE `tbl_customer_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
