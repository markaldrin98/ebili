<?php 
include('connection.php'); 
include('tags.php'); 
?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
  <style>
    *{
      margin: 0;
      padding: 0;
    }
    .navbar-default .navbar-nav > li > a {
      color: #449d44 !important;
    }

    .navbar-default .navbar-nav > li > a:hover {
      color: #2a772a !important;
    }

    .modal {
     text-align: center;
    }

.product-item {
  float: left;
  background: #ffffff;
  margin: 30px 30px 0px 0px;
  border: #E0E0E0 1px solid;
}

.product-image {
  height: 155px;
  width: 250px;
  background-color: #FFF;
}

.product-tile-footer {
    padding: 15px 15px 0px 15px;
    overflow: auto;
}

.product-title {
  margin-bottom: 20px;
}

.product-price {
  float:left;
}

.cart-action {
  float: right;
}

.zoom-hover {
  border:2px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px; margin: 15px;
}

.zoom-hover:hover {
 border: solid 2px #449d44;
 cursor: pointer;
}



    @media screen and (min-width: 768px) { 
      .modal:before {
        display: inline-block;
        vertical-align: middle;
        content: " ";
        height: 100%;
      }
    }

    .modal-dialog {
      display: inline-block;
      text-align: left;
      vertical-align: middle;
    }
/*
    .navbar-default {
      border-color: #800000 !important;
    }*/

  </style>
</head>
<body>

<nav class="navbar navbar-default" style="padding: 10px;">
  <div class="container-fluid">
    <div class="navbar-header" style="background: ">
  
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>

      <a style="font-weight: bold; margin-left: 0.5px; color: #449d44;" class="navbar-brand " href="index.php"><span class="glyphicon glyphicon-shopping-cart"></span> E-Bili System</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class=""><a href="index.php">Home</a></li>
        <!-- <li><a href="#">Page 1</a></li>
        <li><a href="#">Page 2</a></li> 
 -->      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="customer_registration.php"><span class="glyphicon glyphicon-user"></span> Register</a></li>
        <li data-toggle="modal" data-target="#myModal"><a href="#"><span class="glyphicon glyphicon-log-in" class="btn btn-info btn-lg"></span> Login</a></li>
      </ul>
    </div>
  </div>
</nav>


<div class="modal" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Choose your user type</h4>
        </div>
        <div class="modal-body">
          <a href="customer_login.php"><button type="button" class="btn btn-primary btn-block" style="margin-bottom: 1rem;">Log in as Customer</button></a>
          <a href="admin_login.php"><button type="button" class="btn btn-primary btn-block">Log in as Admin</button></a>
        </div>
        
      </div>
      
    </div>
  </div>

<div class="jumbotron text-center mt-4">
  
  <h1>Welcome to E-Bili System!</h1>
  <p>E-Bili Opening. Coming Soon!</p>
</div>
  
<div class="container">
  <div class="row">
  
    <h3 align="center">Shopping Cart</h3>
    <br>
   

    <?php 

    if(isset($_POST["add_to_cart"]))
{
  if(isset($_SESSION["shopping_cart"]))
  {
    $item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
    if(!in_array($_GET["id"], $item_array_id))
    {
      $count = count($_SESSION["shopping_cart"]);
      $item_array = array(
        'item_id'     =>  $_GET["id"],
        'item_name'     =>  $_POST["hidden_name"],
        'item_price'    =>  $_POST["hidden_price"],
        'item_quantity'   =>  $_POST["quantity"]
      );
      $_SESSION["shopping_cart"][$count] = $item_array;
    }
    else
    {
      echo '<script>alert("Item Already Added")</script>';
    }
  }
  else
  {
    $item_array = array(
      'item_id'     =>  $_GET["id"],
      'item_name'     =>  $_POST["hidden_name"],
      'item_price'    =>  $_POST["hidden_price"],
      'item_quantity'   =>  $_POST["quantity"]
    );
    $_SESSION["shopping_cart"][0] = $item_array;
  }
}

if(isset($_GET["action"]))
{
  if($_GET["action"] == "delete")
  {
    foreach($_SESSION["shopping_cart"] as $keys => $values)
    {
      if($values["item_id"] == $_GET["id"])
      {
        unset($_SESSION["shopping_cart"][$keys]);
        echo '<script>alert("Item Removed")</script>';
        echo '<script>window.location="customer_dashboard.php"</script>';
      }
    }
  }
}


$query = "SELECT * FROM tbl_categories ORDER BY id ASC";
        $result = mysqli_query($conn, $query);
        if(mysqli_num_rows($result) > 0)
        {
          while($row = mysqli_fetch_array($result))
          {
        ?>
      <div class="col-md-4">
        <form method="post" action="customer_dashboard.php?action=add&id=<?php echo $row["id"]; ?>">

            <a href="product.php?action=add&id=<?php echo $row["id"]; ?>">
              <div align="center" class="zoom-hover">
            


             <img src="shopping_cart/<?php echo $row["image"]; ?>" class="img-responsive " style="width: 150px; height: 150px;"/><br />


            <h4 class="text-info"><?php echo $row["category_name"]; ?></h4>
  <!--  
            <h4 class="text-danger">$ <?php echo $row["price"]; ?></h4>

            <input type="text" name="quantity" value="1" class="form-control" />

            <input type="hidden" name="hidden_name" value="<?php echo $row["category_name"]; ?>" />

            <input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />


            
            <input type="submit" name="add_to_cart" style="margin-top:5px;" 


            <?php if(!isset($_SESSION['username'])) { 
                echo 'class="btn btn-disabled" disabled';
              }
              else{
                  echo 'class="btn btn-success"';
              }
            ?> 
            class="" value="Add to Cart" />
 -->
          </div>
</a>
        </form>
      </div>
      <?php
          }
        }
      ?>
      
    </div>
  </div>
  <br />
  </body>
</html>