<?php 
include('connection.php'); 
include('tags.php'); 
?>

<!DOCTYPE html>
<html>
<head>
  <title>Maroon Board</title>
  <style>
    *{
      margin: 0;
      padding: 0;
    }
    .navbar-default .navbar-nav > li > a {
      color: #800000 !important;
    }

    .navbar-default .navbar-nav > li > a:hover {
      color: #460000 !important;
    }

    .default_red:hover {
      border: 1px solid #800000; border-radius: 20px;
    }
/*
    .navbar-default {
      border-color: #800000 !important;
    }*/

  </style>
</head>
<body>

<?php 
include('admin_navbar.php');

?>


<div class="jumbotron text-center mt-4">
  
<?php 
$username = $_SESSION['username'];
$query = mysqli_query($conn, "SELECT * FROM tbl_customer_credentials");

?>



<div class="container">
<table class='table table-bordered table-striped'>
  <tr style="background: #d9d9d9 !important; text-align: center;">
      <th>ID</th>
      <th>Last Name</th>
      <th>First Name</th>
      <th>Middle Name</th>
      <th>Username</th>   
      <th>Password</th> 
      <th>Email</th>      
      <th>Address</th> 
      <th>Contact Number</th>                              
  </tr>

  <?php while($row = mysqli_fetch_array($query)){ ?>
  <tr>
      <td><?php echo $row["id"]; ?> </td>
      <td><?php echo $row["last_name"]; ?> </td>
      <td><?php echo $row["first_name"]; ?> </td>
      <td><?php echo $row["middle_name"]; ?> </td>
      
      <td><?php echo $row["username"]; ?> </td>
      <td><?php echo $row["password"]; ?> </td>
      <td><?php echo $row["email"]; ?> </td>
      <td><?php echo $row["address"]; ?> </td>
      <td><?php echo $row["contact_number"]; ?> </td>
  </tr>
  <?php
  
}

  ?>

</table>


</div>
</div>


</body>
</html>